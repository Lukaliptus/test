# HEXGLITCH Forum Webhook Tool

A small hosted web app for creating Discord Forum posts through webhooks.

## Features

- Creates new forum posts using `thread_name`
- Posts inside existing forum threads using `thread_id`
- Keeps your Discord webhook hidden in server environment variables
- Supports media attachments
- Includes HEXGLITCH-style templates

## Local setup

```bash
npm install
cp .env.local.example .env.local
npm run dev
```

Edit `.env.local`:

```env
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_ID/YOUR_TOKEN
APP_PASSCODE=your-private-password
```

Open:

```txt
http://localhost:3000
```

## Deploy to Vercel

1. Upload this project to GitHub.
2. Go to Vercel and import the GitHub repo.
3. Add environment variables:
   - `DISCORD_WEBHOOK_URL`
   - `APP_PASSCODE`
4. Deploy.
5. Open the Vercel URL and use your passcode.

## Important

For Discord forum channels:
- Use `thread_name` to create a new forum post.
- Use `thread_id` to post inside an existing forum post.
- Do not use both at the same time.

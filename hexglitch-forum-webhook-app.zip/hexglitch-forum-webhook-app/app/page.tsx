"use client";

import { useMemo, useState } from "react";
import { Send, ShieldCheck } from "lucide-react";

const divider = "━━━━━━━━━━━━━━━━━━━━━━━━━━━";

const templates: Record<string, string> = {
  banner: `Animated banners designed for gaming promotions, focused on impact and visibility.

${divider}

✦ For all types of games and content

${divider}

✦ Click media for full preview`,
  update: `✦ Portfolio update — animated banner showcases added.

${divider}

• Added new gaming banner animations
• Updated motion design section

${divider}

✦ Explore them in the portfolio section`,
  blank: ""
};

export default function Home() {
  const [mode, setMode] = useState("create");
  const [passcode, setPasscode] = useState("");
  const [threadName, setThreadName] = useState("Gaming Banner Animations");
  const [threadId, setThreadId] = useState("");
  const [username, setUsername] = useState("HEXGLITCH");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [content, setContent] = useState(templates.banner);
  const [files, setFiles] = useState<FileList | null>(null);
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState<{type: "ok" | "err", text: string} | null>(null);

  const preview = useMemo(() => content || "Your preview will appear here.", [content]);

  async function sendPost() {
    setStatus(null);

    if (mode === "create" && !threadName.trim()) {
      setStatus({ type: "err", text: "Thread name is required to create a forum post." });
      return;
    }

    if (mode === "reply" && !threadId.trim()) {
      setStatus({ type: "err", text: "Thread ID is required to post inside an existing forum post." });
      return;
    }

    setSending(true);

    try {
      const form = new FormData();
      form.append("mode", mode);
      form.append("passcode", passcode);
      form.append("thread_name", threadName);
      form.append("thread_id", threadId);
      form.append("username", username);
      form.append("avatar_url", avatarUrl);
      form.append("content", content);

      if (files) {
        Array.from(files).slice(0, 10).forEach((file) => form.append("files", file));
      }

      const res = await fetch("/api/send", {
        method: "POST",
        body: form
      });

      const data = await res.json();

      if (!res.ok) {
        setStatus({ type: "err", text: data.error || "Failed to send." });
      } else {
        setStatus({ type: "ok", text: "Posted successfully." });
      }
    } catch (error) {
      setStatus({ type: "err", text: "Network error. Check your deployment and webhook setup." });
    } finally {
      setSending(false);
    }
  }

  return (
    <main>
      <div className="header">
        <div>
          <span className="badge"><ShieldCheck size={15} />&nbsp; Forum webhook tool</span>
          <h1>HEXGLITCH Forum Poster</h1>
          <p>Create Discord forum posts with <b>thread_name</b> built in, attach media, and keep your webhook hidden on the server.</p>
        </div>
      </div>

      <div className="grid">
        <section className="card">
          <div className="row">
            <div>
              <label>Mode</label>
              <select value={mode} onChange={(e) => setMode(e.target.value)}>
                <option value="create">Create new forum post</option>
                <option value="reply">Post inside existing thread</option>
              </select>
            </div>
            <div>
              <label>App Passcode</label>
              <input type="password" value={passcode} onChange={(e) => setPasscode(e.target.value)} placeholder="Set in Vercel env" />
            </div>
          </div>

          {mode === "create" ? (
            <>
              <label>Thread Name / Forum Post Title</label>
              <input value={threadName} onChange={(e) => setThreadName(e.target.value)} placeholder="Example: Gaming Banner Animations" />
            </>
          ) : (
            <>
              <label>Existing Thread ID</label>
              <input value={threadId} onChange={(e) => setThreadId(e.target.value)} placeholder="Numbers only, not the full Discord URL" />
            </>
          )}

          <div className="row">
            <div>
              <label>Webhook Username</label>
              <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="HEXGLITCH" />
            </div>
            <div>
              <label>Avatar URL optional</label>
              <input value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} placeholder="https://..." />
            </div>
          </div>

          <label>Template</label>
          <select onChange={(e) => setContent(templates[e.target.value])} defaultValue="banner">
            <option value="banner">Animated banner showcase</option>
            <option value="update">Portfolio update</option>
            <option value="blank">Blank</option>
          </select>

          <label>Message Content</label>
          <textarea value={content} onChange={(e) => setContent(e.target.value)} />

          <label>Media Attachments optional</label>
          <input type="file" multiple onChange={(e) => setFiles(e.target.files)} />

          <button onClick={sendPost} disabled={sending}>
            <Send size={16} /> {sending ? "Sending..." : "Send to Discord"}
          </button>

          {status && <div className={`status ${status.type}`}>{status.text}</div>}

          <p className="footer-note">For forum channels, create mode sends <b>thread_name</b>. Reply mode sends with <b>thread_id</b>.</p>
        </section>

        <aside className="card">
          <label>Live Preview</label>
          <div className="preview">{preview}</div>
          <p className="small">Discord may render attachments below the message. Large files depend on your server/upload limits.</p>
        </aside>
      </div>
    </main>
  );
}

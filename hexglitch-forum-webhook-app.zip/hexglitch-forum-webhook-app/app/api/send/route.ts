export const runtime = "nodejs";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

export async function POST(req: Request) {
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
  const expectedPasscode = process.env.APP_PASSCODE;

  if (!webhookUrl) {
    return json({ error: "Missing DISCORD_WEBHOOK_URL environment variable." }, 500);
  }

  const incoming = await req.formData();

  const passcode = String(incoming.get("passcode") || "");
  if (expectedPasscode && passcode !== expectedPasscode) {
    return json({ error: "Invalid app passcode." }, 401);
  }

  const mode = String(incoming.get("mode") || "create");
  const threadName = String(incoming.get("thread_name") || "").trim();
  const threadId = String(incoming.get("thread_id") || "").trim();
  const content = String(incoming.get("content") || "").trim();
  const username = String(incoming.get("username") || "").trim();
  const avatarUrl = String(incoming.get("avatar_url") || "").trim();

  if (!content) {
    return json({ error: "Message content is required." }, 400);
  }

  if (mode === "create" && !threadName) {
    return json({ error: "thread_name is required when creating a forum post." }, 400);
  }

  if (mode === "reply" && !threadId) {
    return json({ error: "thread_id is required when posting inside an existing thread." }, 400);
  }

  if (mode === "create" && threadId) {
    return json({ error: "Use either thread_name or thread_id, not both." }, 400);
  }

  const files = incoming.getAll("files").filter((item): item is File => item instanceof File && item.size > 0);

  const payload: Record<string, unknown> = {
    content,
    allowed_mentions: { parse: [] }
  };

  if (mode === "create") payload.thread_name = threadName;
  if (username) payload.username = username;
  if (avatarUrl) payload.avatar_url = avatarUrl;

  let discordUrl = webhookUrl;
  if (mode === "reply") {
    const separator = webhookUrl.includes("?") ? "&" : "?";
    discordUrl = `${webhookUrl}${separator}thread_id=${encodeURIComponent(threadId)}`;
  }

  let discordResponse: Response;

  if (files.length > 0) {
    const outbound = new FormData();
    outbound.append("payload_json", JSON.stringify(payload));
    files.slice(0, 10).forEach((file, index) => outbound.append(`files[${index}]`, file, file.name));

    discordResponse = await fetch(discordUrl, {
      method: "POST",
      body: outbound
    });
  } else {
    discordResponse = await fetch(discordUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  const text = await discordResponse.text();

  if (!discordResponse.ok) {
    return json({
      error: "Discord rejected the request.",
      status: discordResponse.status,
      details: text
    }, discordResponse.status);
  }

  return json({ ok: true });
}

import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HEXGLITCH Forum Webhook Tool",
  description: "Create Discord forum posts using webhooks with thread_name built in."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
